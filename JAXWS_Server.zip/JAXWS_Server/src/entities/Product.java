package entities;

public class Product {
	private String id;
	private String nam;

	private long price;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNam() {
		return nam;
	}

	public Product() {
		super();
		
	}

	public Product(String id, String nam, long price) {
		super();
		this.id = id;
		this.nam = nam;
		this.price = price;
	}

	public void setNam(String nam) {
		this.nam = nam;
	}

	public long getPrice() {
		return price;
	}

	public void setPrice(long price) {
		this.price = price;
	}


}
