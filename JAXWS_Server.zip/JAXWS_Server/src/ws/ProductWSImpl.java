package ws;
import java.util.List;

import javax.jws.WebService;

import entities.*;
import dao.*;

@WebService(endpointInterface="ws.ProductwS")
public class ProductWSImpl implements ProductwS {
	
	private ProductDAO  productdao=new ProductDAO();

	@Override
	public Product find() {
		// TODO Auto-generated method stub
		return this.productdao.find();
	}

	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return this.productdao.findALL();
	}

}
 