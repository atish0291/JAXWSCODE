package ws;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import entities.*;

@WebService
public interface ProductwS {

	@WebMethod
	public Product find();
	
	@WebMethod
	public List<Product> findAll() ;
}
