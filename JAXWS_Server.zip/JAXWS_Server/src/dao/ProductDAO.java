package dao;

import java.util.ArrayList;
import java.util.List;

import entities.Product;
public class ProductDAO {
	public Product find() {
		return new Product("p01","name 1",100);
	}
	public List<Product> findALL() {
		List<Product> result= new ArrayList<Product>();
		result.add(new Product("p01","name 1",100));
		result.add(new Product("p02","name 2",100));
		result.add(new Product("p03","name 3",100));
		return result;
	}
 
}
