package ws;

public class ProductwSProxy implements ws.ProductwS {
  private String _endpoint = null;
  private ws.ProductwS productwS = null;
  
  public ProductwSProxy() {
    _initProductwSProxy();
  }
  
  public ProductwSProxy(String endpoint) {
    _endpoint = endpoint;
    _initProductwSProxy();
  }
  
  private void _initProductwSProxy() {
    try {
      productwS = (new ws.ProductWSImplServiceLocator()).getProductWSImplPort();
      if (productwS != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)productwS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)productwS)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (productwS != null)
      ((javax.xml.rpc.Stub)productwS)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public ws.ProductwS getProductwS() {
    if (productwS == null)
      _initProductwSProxy();
    return productwS;
  }
  
  public ws.Product find() throws java.rmi.RemoteException{
    if (productwS == null)
      _initProductwSProxy();
    return productwS.find();
  }
  
  public ws.Product[] findAll() throws java.rmi.RemoteException{
    if (productwS == null)
      _initProductwSProxy();
    return productwS.findAll();
  }
  
  
}