
import java.util.List;

import ws.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			/*DemoImplService demo1= new DemoImplServiceLocator();
			Demo demo=demo1.getDemoImplPort();
			System.out.println(demo.helloworld());
			System.out.println(demo.hi("atish"));*/
			ProductWSImplService ps= new ProductWSImplServiceLocator();
			ProductwS pws=ps.getProductWSImplPort();
			Product product=pws.find();
			System.out.println(product.getId());
			System.out.println(product.getNam());
			System.out.println(product.getPrice());
			Product []listproduct=pws.findAll();
			for(Product p: listproduct) {
				System.out.println(p.getId());
				System.out.println(p.getNam());
				System.out.println(p.getPrice());
			}
			//System.out.println(demo.hi("atish"));
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
